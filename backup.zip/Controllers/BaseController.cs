﻿using Ciloci.Flee;
using com.SML.BIGTRONS.Models;
using com.SML.BIGTRONS.ViewModels;
using com.SML.Lib.Common;
using Ext.Net;
using Ext.Net.MVC;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.Security;
using SX = System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using System.Xml.Xsl;
using SW = System.Web;
using System.Xml.XPath;
using com.SML.BIGTRONS.DataAccess;
using System.Text.RegularExpressions;

namespace com.SML.BIGTRONS.Controllers
{
    public class BaseController : Controller
    {
        private const string _STRMENUIDPRE = "mnu";
        /// <summary>
        /// To check if the user is authorized to access the page
        /// </summary>
        /// <returns></returns>
        private bool IsAuthorized()
        {
            bool m_boolReturn = false;

            try
            {
                string m_strRoleID = Request.Cookies[FormsAuthentication.FormsCookieName + ".RoleID"].Value;
                string m_strMenuUrl = Global.MenuUrl;
                DRoleMenuActionDA m_objDRoleMenuActionDA = new DRoleMenuActionDA();
                m_objDRoleMenuActionDA.ConnectionStringName = Global.ConnStrConfigName;

                Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();
                List<object> m_lstFilter = new List<object>();
                m_lstFilter.Add(Operator.Equals);
                m_lstFilter.Add(m_strRoleID);
                m_objFilter.Add(RoleMenuActionVM.Prop.RoleID.Map, m_lstFilter);

                m_lstFilter = new List<object>();
                m_lstFilter.Add(Operator.Equals);
                m_lstFilter.Add(m_strMenuUrl);
                m_objFilter.Add(RoleMenuActionVM.Prop.MenuUrl.Map, m_lstFilter);

                Dictionary<int, DataSet> m_dicDRoleMenuActionDA = m_objDRoleMenuActionDA.SelectBC(0, null, true, null, m_objFilter, null, null, null);
                int m_intCount = 0;
                foreach (KeyValuePair<int, DataSet> m_kvpDRoleMenuActionDA in m_dicDRoleMenuActionDA)
                {
                    m_intCount = m_kvpDRoleMenuActionDA.Key;
                    break;
                }
                m_boolReturn = m_intCount > 0;
                //message = m_objDRoleMenuActionDA.Message;
            }
            catch (Exception ex)
            {
                //message = ex.Message;
            }

            return m_boolReturn;
        }

        /// <summary>
        /// Check user identity everytime open new View
        /// </summary>
        protected void Initialize()
        {
            try
            {
                string m_strReturnUrl = string.Empty;
                if (!SW.HttpContext.Current.User.Identity.IsAuthenticated)
                {
                    object m_objMessage = "Please login to access this page";
                    m_strReturnUrl = "~/" + "?ReturnUrl=" + Request.FilePath.ToString() + "&e=0";
                    Response.Redirect(m_strReturnUrl);
                }
                else
                {
                    string m_strMessage = string.Empty;
                    if (!IsAuthorized())
                    {
                        m_strReturnUrl = "~/" + "?ReturnUrl=" + Request.FilePath.ToString() + "&e=1";
                        Response.Redirect(m_strReturnUrl);
                    }
                }

                ViewBag.Title = Global.GetTitle(this.GetType());
            }
            catch (Exception ex)
            {

            }
        }

        /// <summary>
        /// Method to check if current user on current menu has access as parsed
        /// </summary>
        /// <param name="actionID">Action ID to check</param>
        /// <returns>Has access or not</returns>
        protected bool HasAccess(string actionID)
        {
            bool m_boolReturn = false;

            try
            {
                string m_strRoleID = Request.Cookies[FormsAuthentication.FormsCookieName + ".RoleID"].Value;
                //string m_strMenuUrl = (Request.UrlReferrer == null || !Request.Url.AbsoluteUri.Contains(Request.UrlReferrer.AbsoluteUri) ?
                //    Request.FilePath : Request.UrlReferrer.AbsolutePath);
                //string m_strMenuUrl = "/" + this.GetType().Name.Replace("Controller", "");
                string m_strMenuID = _STRMENUIDPRE + this.GetType().Name.Replace("Controller", "");
                DRoleMenuActionDA m_objDRoleMenuActionDA = new DRoleMenuActionDA();
                m_objDRoleMenuActionDA.ConnectionStringName = Global.ConnStrConfigName;

                Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();
                List<object> m_lstFilter = new List<object>();
                m_lstFilter.Add(Operator.Equals);
                m_lstFilter.Add(m_strRoleID);
                m_objFilter.Add(RoleMenuActionVM.Prop.RoleID.Map, m_lstFilter);

                m_lstFilter = new List<object>();
                m_lstFilter.Add(Operator.Equals);
                m_lstFilter.Add(m_strMenuID);
                m_objFilter.Add(RoleMenuActionVM.Prop.MenuID.Map, m_lstFilter);

                m_lstFilter = new List<object>();
                m_lstFilter.Add(Operator.Equals);
                m_lstFilter.Add(actionID);
                m_objFilter.Add(RoleMenuActionVM.Prop.ActionID.Map, m_lstFilter);

                m_lstFilter = new List<object>();
                m_lstFilter.Add(Operator.Equals);
                m_lstFilter.Add("true");
                m_objFilter.Add("'" + SW.HttpContext.Current.User.Identity.IsAuthenticated.ToString().ToLower() + "'", m_lstFilter);

                Dictionary<int, DataSet> m_dicDRoleMenuActionDA = m_objDRoleMenuActionDA.SelectBC(0, null, true, null, m_objFilter, null, null, null);
                int m_intCount = 0;
                foreach (KeyValuePair<int, DataSet> m_kvpDRoleMenuActionDA in m_dicDRoleMenuActionDA)
                {
                    m_intCount = m_kvpDRoleMenuActionDA.Key;
                    break;
                }
                m_boolReturn = m_intCount > 0;
            }
            catch (Exception ex)
            {
                return false;
            }

            return m_boolReturn;
        }

        /// <summary>
        /// Method to get list of access (Action ID) for current user on current menu
        /// </summary>
        /// <returns>Access (Action ID) List for current user on current menu</returns>
        protected List<string> GetActionList()
        {
            List<string> m_lstReturn = new List<string>();

            try
            {
                string m_strRoleID = Request.Cookies[FormsAuthentication.FormsCookieName + ".RoleID"].Value;
                //string m_strMenuUrl = (Request.UrlReferrer == null || !Request.Url.AbsoluteUri.Contains(Request.UrlReferrer.AbsoluteUri) ?
                //    Request.FilePath : Request.UrlReferrer.AbsolutePath);
                //string m_strMenuUrl = "/" + this.GetType().Name.Replace("Controller", "");
                string m_strMenuID = _STRMENUIDPRE + this.GetType().Name.Replace("Controller", "");
                DRoleMenuActionDA m_objDRoleMenuActionDA = new DRoleMenuActionDA();
                m_objDRoleMenuActionDA.ConnectionStringName = Global.ConnStrConfigName;

                List<string> m_lstSelect = new List<string>();
                m_lstSelect.Add(RoleMenuActionVM.Prop.ActionID.MapAlias);

                Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();
                List<object> m_lstFilter = new List<object>();
                m_lstFilter.Add(Operator.Equals);
                m_lstFilter.Add(m_strRoleID);
                m_objFilter.Add(RoleMenuActionVM.Prop.RoleID.Map, m_lstFilter);

                m_lstFilter = new List<object>();
                m_lstFilter.Add(Operator.Equals);
                m_lstFilter.Add(m_strMenuID);
                m_objFilter.Add(RoleMenuActionVM.Prop.MenuID.Map, m_lstFilter);

                Dictionary<int, DataSet> m_dicDRoleMenuActionDA = m_objDRoleMenuActionDA.SelectBC(0, null, false, m_lstSelect, m_objFilter, null, null, null);
                if (m_objDRoleMenuActionDA.Message == string.Empty)
                    m_lstReturn = m_dicDRoleMenuActionDA[0].Tables[0].AsEnumerable().Select(m_drDRoleMenuActionDA
                        => m_drDRoleMenuActionDA[RoleMenuActionVM.Prop.ActionID.Name].ToString()).ToList();
            }
            catch (Exception ex)
            {

            }

            return m_lstReturn;
        }

        /// <summary>
        /// Method to get list of access (Action ID) for current user on current menu
        /// </summary>
        /// <returns>Access (Action ID) List for current user on current menu</returns>
        protected HasAccessVM GetHasAccess()
        {
            List<string> m_lstAccess = GetActionList();
            HasAccessVM m_objHasAccessVM = new HasAccessVM();
            m_objHasAccessVM.Add = m_lstAccess.Contains(General.GetVariableName(() => m_objHasAccessVM.Add));
            m_objHasAccessVM.Cancel = m_lstAccess.Contains(General.GetVariableName(() => m_objHasAccessVM.Cancel));
            m_objHasAccessVM.Delete = m_lstAccess.Contains(General.GetVariableName(() => m_objHasAccessVM.Delete));
            m_objHasAccessVM.Generate = m_lstAccess.Contains(General.GetVariableName(() => m_objHasAccessVM.Generate));
            m_objHasAccessVM.Preview = m_lstAccess.Contains(General.GetVariableName(() => m_objHasAccessVM.Preview));
            m_objHasAccessVM.Print = m_lstAccess.Contains(General.GetVariableName(() => m_objHasAccessVM.Print));
            m_objHasAccessVM.Read = m_lstAccess.Contains(General.GetVariableName(() => m_objHasAccessVM.Read));
            m_objHasAccessVM.Verify = m_lstAccess.Contains(General.GetVariableName(() => m_objHasAccessVM.Verify));
            m_objHasAccessVM.Unverify = m_lstAccess.Contains(General.GetVariableName(() => m_objHasAccessVM.Unverify));
            m_objHasAccessVM.Update = m_lstAccess.Contains(General.GetVariableName(() => m_objHasAccessVM.Update));
            m_objHasAccessVM.Upload = m_lstAccess.Contains(General.GetVariableName(() => m_objHasAccessVM.Upload));
            m_objHasAccessVM.Export = m_lstAccess.Contains(General.GetVariableName(() => m_objHasAccessVM.Export));
            m_objHasAccessVM.Mapping = m_lstAccess.Contains(General.GetVariableName(() => m_objHasAccessVM.Mapping));
            m_objHasAccessVM.Post = m_lstAccess.Contains(General.GetVariableName(() => m_objHasAccessVM.Post));
            m_objHasAccessVM.Reverse = m_lstAccess.Contains(General.GetVariableName(() => m_objHasAccessVM.Reverse));

            return m_objHasAccessVM;
        }

        /// <summary>
        /// Method to get object's value for current user on current menu
        /// </summary>
        /// <param name="objectID">Object ID that its value will be retrieved</param>
        /// <returns>Value of object</returns>
        protected string GetMenuObject(string objectID)
        {
            string m_strReturn = string.Empty;

            try
            {
                string m_strRoleID = Request.Cookies[FormsAuthentication.FormsCookieName + ".RoleID"].Value;
                //string m_strMenuUrl = (Request.UrlReferrer == null || !Request.Url.AbsoluteUri.Contains(Request.UrlReferrer.AbsoluteUri) ?
                //    Request.FilePath : Request.UrlReferrer.AbsolutePath);
                //string m_strMenuUrl = "/" + this.GetType().Name.Replace("Controller", "");
                string m_strMenuID = _STRMENUIDPRE + this.GetType().Name.Replace("Controller", "");
                DRoleMenuObjectDA m_objDRoleMenuObjectDA = new DRoleMenuObjectDA();
                m_objDRoleMenuObjectDA.ConnectionStringName = Global.ConnStrConfigName;

                List<string> m_lstSelect = new List<string>();
                m_lstSelect.Add(RoleMenuObjectVM.Prop.Value.MapAlias);

                Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();
                List<object> m_lstFilter = new List<object>();
                m_lstFilter.Add(Operator.Equals);
                m_lstFilter.Add(m_strRoleID);
                m_objFilter.Add(RoleMenuObjectVM.Prop.RoleID.Map, m_lstFilter);

                m_lstFilter = new List<object>();
                m_lstFilter.Add(Operator.Equals);
                m_lstFilter.Add(m_strMenuID);
                m_objFilter.Add(RoleMenuObjectVM.Prop.MenuID.Map, m_lstFilter);

                m_lstFilter = new List<object>();
                m_lstFilter.Add(Operator.Equals);
                m_lstFilter.Add(objectID);
                m_objFilter.Add(RoleMenuObjectVM.Prop.ObjectID.Map, m_lstFilter);

                Dictionary<int, DataSet> m_dicDRoleMenuActionDA = m_objDRoleMenuObjectDA.SelectBC(0, null, false, m_lstSelect, m_objFilter, null, null, null);
                if (m_objDRoleMenuObjectDA.Message == string.Empty)
                    m_strReturn = m_dicDRoleMenuActionDA[0].Tables[0].Rows[0][RoleMenuObjectVM.Prop.Value.Name].ToString();
            }
            catch (Exception ex)
            {

            }

            return string.IsNullOrEmpty(m_strReturn) ? "True" : m_strReturn;
        }

        /// <summary>
        /// Method to get object's value for current user on current menu
        /// </summary>
        /// <param name="objectID">Object ID that its value will be retrieved</param>
        /// <returns>Value of object</returns>
        protected Dictionary<string, string> GetMenuObjectList()
        {
            Dictionary<string, string> m_dicReturn = new Dictionary<string, string>();

            try
            {
                string m_strRoleID = Request.Cookies[FormsAuthentication.FormsCookieName + ".RoleID"].Value;
                //string m_strMenuUrl = (Request.UrlReferrer == null || !Request.Url.AbsoluteUri.Contains(Request.UrlReferrer.AbsoluteUri) ?
                //    Request.FilePath : Request.UrlReferrer.AbsolutePath);
                //string m_strMenuUrl = "/" + this.GetType().Name.Replace("Controller", "");
                string m_strMenuID = _STRMENUIDPRE + this.GetType().Name.Replace("Controller", "");
                DRoleMenuObjectDA m_objDRoleMenuObjectDA = new DRoleMenuObjectDA();
                m_objDRoleMenuObjectDA.ConnectionStringName = Global.ConnStrConfigName;

                List<string> m_lstSelect = new List<string>();
                m_lstSelect.Add(RoleMenuObjectVM.Prop.ObjectID.MapAlias);
                m_lstSelect.Add(RoleMenuObjectVM.Prop.Value.MapAlias);

                Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();
                List<object> m_lstFilter = new List<object>();
                m_lstFilter.Add(Operator.Equals);
                m_lstFilter.Add(m_strRoleID);
                m_objFilter.Add(RoleMenuObjectVM.Prop.RoleID.Map, m_lstFilter);

                m_lstFilter = new List<object>();
                m_lstFilter.Add(Operator.Equals);
                m_lstFilter.Add(m_strMenuID);
                m_objFilter.Add(RoleMenuObjectVM.Prop.MenuID.Map, m_lstFilter);

                Dictionary<int, DataSet> m_dicDRoleMenuActionDA = m_objDRoleMenuObjectDA.SelectBC(0, null, false, m_lstSelect, m_objFilter, null, null, null);
                if (m_objDRoleMenuObjectDA.Message == string.Empty)
                    m_dicReturn = m_dicDRoleMenuActionDA[0].Tables[0].AsEnumerable().ToDictionary(
                        m_drDRoleMenuActionDA => m_drDRoleMenuActionDA[RoleMenuObjectVM.Prop.ObjectID.Name].ToString(),
                        m_drDRoleMenuActionDA => m_drDRoleMenuActionDA[RoleMenuObjectVM.Prop.Value.Name].ToString()
                        );
            }
            catch (Exception ex)
            {

            }

            return m_dicReturn;
        }

        protected bool IsAggregate(string columnName)
        {
            columnName = columnName.Replace(" ", "");
            foreach (string m_strFormulaName in Global.AggregateFunction)
            {
                if (columnName.Contains(m_strFormulaName))
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Method to get List of Budget Plan Version from Budget Plan Package
        /// </summary>
        /// <param name="packageID">Package ID to filter</param>
        /// <returns>List Budget Plan Version</returns>
        protected List<PackageListVM> GetPackageList(string packageID)
        {
            DPackageListDA m_objDPackageListDA = new DPackageListDA();
            m_objDPackageListDA.ConnectionStringName = Global.ConnStrConfigName;

            Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();

            List<object> m_lstFilter = new List<object>();
            m_lstFilter.Add(Operator.Equals);
            m_lstFilter.Add(packageID);
            m_objFilter.Add(PackageListVM.Prop.PackageID.Map, m_lstFilter);

            List<string> m_lstSelect = new List<string>();
            m_lstSelect.Add(PackageListVM.Prop.BudgetPlanID.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.BudgetPlanVersion.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.BudgetPlanTemplateDesc.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.BudgetPlanTemplateID.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.ProjectID.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.ProjectDesc.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.ClusterID.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.ClusterDesc.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.StatusID.MapAlias);

            List<PackageListVM> m_lstPackageListVM = new List<PackageListVM>();

            Dictionary<int, DataSet> m_dicDPackageListDA = m_objDPackageListDA.SelectBC(0, null, false, m_lstSelect, m_objFilter, null, null, null, null);
            if (m_objDPackageListDA.Success && m_objDPackageListDA.Message.Length == 0)
            {
                m_lstPackageListVM = (
                    from DataRow m_drDPackageListDA in m_dicDPackageListDA[0].Tables[0].Rows
                    select new PackageListVM()
                    {
                        BudgetPlanID = m_drDPackageListDA[PackageListVM.Prop.BudgetPlanID.Name].ToString(),
                        BudgetPlanTemplateDesc = m_drDPackageListDA[PackageListVM.Prop.BudgetPlanTemplateDesc.Name].ToString(),
                        ProjectDesc = m_drDPackageListDA[PackageListVM.Prop.ProjectDesc.Name].ToString(),
                        ClusterDesc = m_drDPackageListDA[PackageListVM.Prop.ClusterDesc.Name].ToString(),
                        StatusID = int.Parse(m_drDPackageListDA[PackageListVM.Prop.StatusID.Name].ToString())
                    }
                ).ToList();
            }

            return m_lstPackageListVM;
        }

        /// <summary>
        /// Method to get detail Budget Plan Package
        /// </summary>
        /// <param name="packageID">Package ID to filter</param>
        /// <returns>PackageVM</returns>
        protected PackageVM GetPackageDetail(string packageID)
        {
            PackageVM m_objPackageVM = new PackageVM();

            TPackageDA m_objTPackageDA = new TPackageDA();
            m_objTPackageDA.ConnectionStringName = Global.ConnStrConfigName;

            Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();

            List<object> m_lstFilter = new List<object>();
            m_lstFilter.Add(Operator.Equals);
            m_lstFilter.Add(packageID);
            m_objFilter.Add(PackageVM.Prop.PackageID.Map, m_lstFilter);

            List<string> m_lstSelect = new List<string>();
            m_lstSelect.Add(PackageVM.Prop.PackageID.MapAlias);
            m_lstSelect.Add(PackageVM.Prop.PackageDesc.MapAlias);
            m_lstSelect.Add(PackageVM.Prop.StatusID.MapAlias);
            m_lstSelect.Add(PackageVM.Prop.StatusDesc.MapAlias);

            Dictionary<int, DataSet> m_dicTPackageDA = m_objTPackageDA.SelectBC(0, null, false, m_lstSelect, m_objFilter, null, null, null, null);

            if (m_objTPackageDA.Success && m_objTPackageDA.Message == String.Empty)
            {
                DataRow m_dr = m_dicTPackageDA[0].Tables[0].Rows[0];
                m_objPackageVM.PackageID = packageID;
                m_objPackageVM.PackageDesc = m_dr[PackageVM.Prop.PackageDesc.Name].ToString();
                m_objPackageVM.StatusID = int.Parse(m_dr[PackageVM.Prop.StatusID.Name].ToString());
                m_objPackageVM.StatusDesc = m_dr[PackageVM.Prop.StatusDesc.Name].ToString();
            }

            return m_objPackageVM;
        }

        /// <summary>
        /// Method to get List of Budget Plan Version from Budget Plan Package
        /// </summary>
        /// <param name="packageID">Package ID to filter</param>
        /// <returns>List Budget Plan Version</returns>
        protected List<PackageListVM> GetPackageListDetail(string packageID)
        {
            DPackageListDA m_objDPackageListDA = new DPackageListDA();
            m_objDPackageListDA.ConnectionStringName = Global.ConnStrConfigName;

            Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();

            List<object> m_lstFilter = new List<object>();
            m_lstFilter.Add(Operator.Equals);
            m_lstFilter.Add(packageID);
            m_objFilter.Add(PackageListVM.Prop.PackageID.Map, m_lstFilter);

            List<string> m_lstSelect = new List<string>();
            m_lstSelect.Add(PackageListVM.Prop.BudgetPlanID.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.Description.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.BudgetPlanTypeDesc.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.BudgetPlanVersion.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.ProjectDesc.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.ClusterDesc.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.RegionDesc.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.DivisionDesc.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.CompanyDesc.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.UnitTypeDesc.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.Area.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.Unit.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.LocationDesc.MapAlias);
            m_lstSelect.Add(PackageListVM.Prop.StatusID.MapAlias);

            List<PackageListVM> m_lstPackageListVM = new List<PackageListVM>();

            Dictionary<int, DataSet> m_dicDPackageListDA = m_objDPackageListDA.SelectBC(0, null, false, m_lstSelect, m_objFilter, null, null, null, null);
            if (m_objDPackageListDA.Success && m_objDPackageListDA.Message.Length == 0)
            {
                m_lstPackageListVM = (
                    from DataRow m_drDPackageListDA in m_dicDPackageListDA[0].Tables[0].Rows
                    select new PackageListVM()
                    {
                        BudgetPlanID = m_drDPackageListDA[PackageListVM.Prop.BudgetPlanID.Name].ToString(),
                        Description = m_drDPackageListDA[PackageListVM.Prop.Description.Name].ToString(),
                        BudgetPlanTypeDesc = m_drDPackageListDA[PackageListVM.Prop.BudgetPlanTypeDesc.Name].ToString(),
                        BudgetPlanVersion = int.Parse(m_drDPackageListDA[PackageListVM.Prop.BudgetPlanVersion.Name].ToString()),
                        ProjectDesc = m_drDPackageListDA[PackageListVM.Prop.ProjectDesc.Name].ToString(),
                        ClusterDesc = m_drDPackageListDA[PackageListVM.Prop.ClusterDesc.Name].ToString(),
                        RegionDesc = m_drDPackageListDA[PackageListVM.Prop.RegionDesc.Name].ToString(),
                        DivisionDesc = m_drDPackageListDA[PackageListVM.Prop.DivisionDesc.Name].ToString(),
                        CompanyDesc = m_drDPackageListDA[PackageListVM.Prop.CompanyDesc.Name].ToString(),
                        UnitTypeDesc = m_drDPackageListDA[PackageListVM.Prop.UnitTypeDesc.Name].ToString(),
                        Area = decimal.Parse(m_drDPackageListDA[PackageListVM.Prop.Area.Name].ToString()),
                        LocationDesc = m_drDPackageListDA[PackageListVM.Prop.LocationDesc.Name].ToString(),
                        StatusID = int.Parse(m_drDPackageListDA[PackageListVM.Prop.StatusID.Name].ToString())
                    }
                ).ToList();
            }

            return m_lstPackageListVM;
        }


        protected bool CheckPriceValidation(string budgetPlanID, int budgetPlanVersion,string tableValidation, ref string message)
        {
            DBudgetPlanVersionStructureDA m_objDBudgetPlanVersionStructureDA = new DBudgetPlanVersionStructureDA();
            m_objDBudgetPlanVersionStructureDA.ConnectionStringName = Global.ConnStrConfigName;

            Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();

            List<object> m_lstFilter = new List<object>();
            m_lstFilter.Add(Operator.Equals);
            m_lstFilter.Add(budgetPlanID);
            m_objFilter.Add(BudgetPlanVersionStructureVM.Prop.BudgetPlanID.Map, m_lstFilter);

            m_lstFilter = new List<object>();
            m_lstFilter.Add(Operator.Equals);
            m_lstFilter.Add(budgetPlanVersion);
            m_objFilter.Add(BudgetPlanVersionStructureVM.Prop.BudgetPlanVersion.Map, m_lstFilter);

            m_lstFilter = new List<object>();
            m_lstFilter.Add(Operator.Equals);
            m_lstFilter.Add("FALSE");
            m_objFilter.Add(tableValidation, m_lstFilter);


            List<string> m_lstSelect = new List<string>();
            m_lstSelect.Add(tableValidation);
            m_lstSelect.Add(BudgetPlanVersionStructureVM.Prop.BudgetPlanVersionStructureID.MapAlias);
            m_lstSelect.Add(BudgetPlanVersionStructureVM.Prop.BudgetPlanVersion.MapAlias);

            Dictionary<int, DataSet> m_dicDBudgetPlanVersionStructureDA = m_objDBudgetPlanVersionStructureDA.SelectBC(0, null, false, m_lstSelect, m_objFilter, null, null, null, null);

            List<BudgetPlanVersionStructureVM> m_lstBudgetPlanVersionStructureVM = new List<BudgetPlanVersionStructureVM>();

            if (m_objDBudgetPlanVersionStructureDA.Success)
            {
                if (m_objDBudgetPlanVersionStructureDA.AffectedRows <= 0)
                    return true;
                else
                {
                    message = "Some item price hasn't entry yet";
                    return false;
                }
            }

            message = m_objDBudgetPlanVersionStructureDA.Message;
            return false;
            
        }


        /// <summary>
        /// Method to get Structure Budget Plan Version, Only Node ItemTypeID equals BOI
        /// </summary>
        /// <param name="budgetPlanID">Budget Plan ID to filter</param>
        /// /// <param name="budgetPlanVersion">Budget Plan Version to filter</param>
        /// <returns>DataTable Budget Plan Version Structure Columns[WorkItem,Amount]</returns>
        protected List<BudgetPlanVersionStructureWSVM> GetBudgetPlanVersionStructureDetail(string budgetPlanID, int budgetPlanVersion)
        {
            List<BudgetPlanVersionStructureWSVM> m_lstData = new List<BudgetPlanVersionStructureWSVM>();

            DataTable m_dtReturn = new DataTable("BudgetPlanStructure_" + budgetPlanID + "_" + budgetPlanVersion.ToString()
                , "BudgetPlanStructure_" + budgetPlanID + "_" + budgetPlanVersion.ToString());
            m_dtReturn.Columns.Add("WorkItem", typeof(string));
            m_dtReturn.Columns.Add("Amount", typeof(string));

            DataRow m_drReturn;

            PackageVM m_objPackageVM = new PackageVM();

            DBudgetPlanVersionStructureDA m_objDBudgetPlanVersionStructureDA = new DBudgetPlanVersionStructureDA();
            m_objDBudgetPlanVersionStructureDA.ConnectionStringName = Global.ConnStrConfigName;

            Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();

            List<object> m_lstFilter = new List<object>();
            m_lstFilter.Add(Operator.Equals);
            m_lstFilter.Add(budgetPlanID);
            m_objFilter.Add(BudgetPlanVersionStructureVM.Prop.BudgetPlanID.Map, m_lstFilter);

            m_lstFilter = new List<object>();
            m_lstFilter.Add(Operator.Equals);
            m_lstFilter.Add(budgetPlanVersion);
            m_objFilter.Add(BudgetPlanVersionStructureVM.Prop.BudgetPlanVersion.Map, m_lstFilter);

            m_lstFilter = new List<object>();
            m_lstFilter.Add(Operator.Equals);
            m_lstFilter.Add("BOI");
            m_objFilter.Add(BudgetPlanVersionStructureVM.Prop.ItemTypeID.Map, m_lstFilter);

            List<string> m_lstSelect = new List<string>();
            m_lstSelect.Add(BudgetPlanVersionStructureVM.Prop.BudgetPlanVersionStructureID.MapAlias);
            m_lstSelect.Add(BudgetPlanVersionStructureVM.Prop.BudgetPlanTemplateDesc.MapAlias);
            m_lstSelect.Add(BudgetPlanVersionStructureVM.Prop.Volume.MapAlias);
            m_lstSelect.Add(BudgetPlanVersionStructureVM.Prop.MaterialAmount.MapAlias);
            m_lstSelect.Add(BudgetPlanVersionStructureVM.Prop.MiscAmount.MapAlias);
            m_lstSelect.Add(BudgetPlanVersionStructureVM.Prop.WageAmount.MapAlias);
            m_lstSelect.Add(BudgetPlanVersionStructureVM.Prop.ItemID.MapAlias);
            m_lstSelect.Add(BudgetPlanVersionStructureVM.Prop.Version.MapAlias);
            m_lstSelect.Add(BudgetPlanVersionStructureVM.Prop.Sequence.MapAlias);
            m_lstSelect.Add(BudgetPlanVersionStructureVM.Prop.ParentItemID.MapAlias);
            m_lstSelect.Add(BudgetPlanVersionStructureVM.Prop.ParentVersion.MapAlias);
            m_lstSelect.Add(BudgetPlanVersionStructureVM.Prop.ParentSequence.MapAlias);
            m_lstSelect.Add(BudgetPlanVersionStructureVM.Prop.ItemDesc.MapAlias);

            Dictionary<int, DataSet> m_dicDBudgetPlanVersionStructureDA = m_objDBudgetPlanVersionStructureDA.SelectBC(0, null, false, m_lstSelect, m_objFilter, null, null, null, null);

            List<BudgetPlanVersionStructureVM> m_lstBudgetPlanVersionStructureVM = new List<BudgetPlanVersionStructureVM>();

            if (m_objDBudgetPlanVersionStructureDA.Success && m_objDBudgetPlanVersionStructureDA.Message == String.Empty)
            {
                m_lstBudgetPlanVersionStructureVM = (
                    from DataRow m_drDBudgetPlanVersionStructureDA in m_dicDBudgetPlanVersionStructureDA[0].Tables[0].Rows
                    select new BudgetPlanVersionStructureVM()
                    {
                        BudgetPlanTemplateDesc = m_drDBudgetPlanVersionStructureDA[BudgetPlanVersionStructureVM.Prop.BudgetPlanTemplateDesc.Name].ToString(),
                        Volume = decimal.Parse(m_drDBudgetPlanVersionStructureDA[BudgetPlanVersionStructureVM.Prop.Volume.Name].ToString()),
                        MaterialAmount = decimal.Parse(m_drDBudgetPlanVersionStructureDA[BudgetPlanVersionStructureVM.Prop.MaterialAmount.Name].ToString()),
                        MiscAmount = decimal.Parse(m_drDBudgetPlanVersionStructureDA[BudgetPlanVersionStructureVM.Prop.MiscAmount.Name].ToString()),
                        WageAmount = decimal.Parse(m_drDBudgetPlanVersionStructureDA[BudgetPlanVersionStructureVM.Prop.WageAmount.Name].ToString()),
                        ParentItemID = m_drDBudgetPlanVersionStructureDA[BudgetPlanVersionStructureVM.Prop.ParentItemID.Name].ToString(),
                        ParentVersion = int.Parse(m_drDBudgetPlanVersionStructureDA[BudgetPlanVersionStructureVM.Prop.ParentVersion.Name].ToString()),
                        ParentSequence = int.Parse(m_drDBudgetPlanVersionStructureDA[BudgetPlanVersionStructureVM.Prop.ParentSequence.Name].ToString()),
                        ItemID = m_drDBudgetPlanVersionStructureDA[BudgetPlanVersionStructureVM.Prop.ItemID.Name].ToString(),
                        ItemDesc = m_drDBudgetPlanVersionStructureDA[BudgetPlanVersionStructureVM.Prop.ItemDesc.Name].ToString(),
                        Version = int.Parse(m_drDBudgetPlanVersionStructureDA[BudgetPlanVersionStructureVM.Prop.Version.Name].ToString()),
                        Sequence = int.Parse(m_drDBudgetPlanVersionStructureDA[BudgetPlanVersionStructureVM.Prop.Sequence.Name].ToString())
                    }
                ).ToList();
            }

            List<BudgetPlanVersionStructureVM> m_lstBudgetPlanVersionStructureVMLevel1 = m_lstBudgetPlanVersionStructureVM.Where(m => m.ParentItemID == "0" && m.ParentVersion == 0 && m.ParentSequence == 0).ToList<BudgetPlanVersionStructureVM>();
            m_lstBudgetPlanVersionStructureVMLevel1 = m_lstBudgetPlanVersionStructureVMLevel1.OrderBy(m => m.Sequence).ToList();
            foreach (BudgetPlanVersionStructureVM item in m_lstBudgetPlanVersionStructureVMLevel1)
            {
                #region Amount Count
                decimal m_decVolume = item.Volume.Value;
                decimal m_decAmount = 0;
                if (m_decVolume > 0)
                {
                    m_decAmount = ((decimal)item.WageAmount + (decimal)item.MiscAmount + (decimal)item.MaterialAmount) * (decimal)item.Volume;
                    m_drReturn = m_dtReturn.NewRow();
                    m_drReturn["WorkItem"] = item.ItemDesc;
                    m_drReturn["Amount"] = m_decAmount;
                    m_dtReturn.Rows.Add(m_drReturn);

                    m_lstData.Add(new BudgetPlanVersionStructureWSVM() { WorkItem = item.ItemDesc, Amount = m_decAmount });
                }
                else
                {
                    CountAmount(m_lstBudgetPlanVersionStructureVM, item.ItemID, item.Version, item.Sequence, ref m_decAmount);
                    m_lstData.Add(new BudgetPlanVersionStructureWSVM() { WorkItem = item.ItemDesc, Amount = m_decAmount });
                    m_drReturn = m_dtReturn.NewRow();
                    m_drReturn["WorkItem"] = item.ItemDesc;
                    m_drReturn["Amount"] = m_decAmount;
                    m_dtReturn.Rows.Add(m_drReturn);
                }
                #endregion
            }

            return m_lstData;
        }

        private void CountAmount(List<BudgetPlanVersionStructureVM> lstAllBOI, string ItemID, int Version, int Sequence, ref decimal Amount)
        {
            List<BudgetPlanVersionStructureVM> m_lstChild = lstAllBOI.Where(m => m.ParentItemID == ItemID && m.ParentVersion == Version && m.ParentSequence == Sequence).ToList();

            foreach (BudgetPlanVersionStructureVM item in m_lstChild)
            {
                if (item.Volume == 0)
                {
                    CountAmount(lstAllBOI, item.ItemID, item.Version, item.Sequence, ref Amount);
                }
                else
                {
                    Amount += ((decimal)item.MiscAmount + (decimal)item.MaterialAmount + (decimal)item.WageAmount) * (decimal)item.Volume;
                }
            }
        }

        protected decimal CalculateFormula(string formula, ref string message, Dictionary<string, decimal> variables = null, bool caseSensitive = false)
        {
            decimal m_decResult = 0;
            try
            {
                ExpressionContext m_excCalculate = new ExpressionContext();
                m_excCalculate.Imports.AddType(typeof(Math));
                m_excCalculate.Options.RealLiteralDataType = RealLiteralDataType.Decimal;
                m_excCalculate.Options.ResultType = typeof(decimal);
                m_excCalculate.Options.CaseSensitive = caseSensitive;
                if (variables != null && variables.Count > 0)
                    foreach (KeyValuePair<string, decimal> m_keyVariable in variables)
                        m_excCalculate.Variables[m_keyVariable.Key] = m_keyVariable.Value;
                m_excCalculate.ParserOptions.RecreateParser();
                IDynamicExpression m_ideCalculate = m_excCalculate.CompileDynamic("1.00*" + formula);
                m_decResult = decimal.Parse(m_ideCalculate.Evaluate().ToString());
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }
            return m_decResult;
        }

        /// <summary>
        /// Export Grid to Xml, Excel, or Comma separated
        /// </summary>
        /// <param name="handler"></param>
        /// <param name="type">One of xml, xls, or csv</param>
        /// <param name="fileName">Filename without extension</param>
        public ActionResult ExportGrid(SubmitHandler handler, string type, string fileName)
        {
            if (!HasAccess(General.GetVariableName(() => new HasAccessVM().Export)))
                return this.Direct(false, General.EnumDesc(MessageLib.NotAuthorized));
            Control.ExportGrid(Response, handler.Xml, type, fileName, Server.MapPath(type == "xls" ? Global.ExcelTemplateLocation : Global.CsvTemplateLocation));
            return this.Direct();
        }

        #region Get Unit Price
        protected decimal? GetUnitPrice(string ItemVersionChildID, string ItemID, ItemPriceVM ItemPriceVM, string ItemTypeID, string ColItemTypeID,DateTime? CreatedDate=null)
        {
            bool m_boolHasFormula = false;
            decimal? m_decUnitPrice = 0;

            List<string> m_lstReferenceParameters = new List<string>();
            Dictionary<string, decimal> m_dicVariables = new Dictionary<string, decimal>();

            if (FilterItemTypeConfig(ItemTypeID, ColItemTypeID))
            {
                ItemVersionChildVM m_objItemVersionChild = GetItemVersionChild(ItemVersionChildID);
                ConfigAHSChildVM m_objConfigAHSChildVM = GetConfigAHSChlid(ItemTypeID);

                if (m_objConfigAHSChildVM.HasFormula)
                {
                    if (!string.IsNullOrEmpty(m_objItemVersionChild.Formula))
                    {
                        m_decUnitPrice = GetFromFormula(ItemVersionChildID, ItemPriceVM, CreatedDate);
                        if (m_decUnitPrice > 0) m_boolHasFormula = true;
                    }
                }
                //else
                //m_decUnitPrice = GetFromItemPrice(ItemID, ItemPriceVM);

                if (!m_boolHasFormula)
                    m_decUnitPrice = GetFromItemPrice(ItemID, ItemPriceVM,CreatedDate);

                //if (m_objConfigAHSChildVM.HasCoefficient)
                //m_decUnitPrice = m_decUnitPrice * m_objItemVersionChild.Coefficient;

            }
            return m_decUnitPrice == 0 ? null : m_decUnitPrice;
        }
        private decimal GetFromItemPrice(string ItemID, ItemPriceVM ItemPriceVM, DateTime? CreatedDate = null, string FilterNotIncluded = "", string ItemVersionChildID = "", decimal? CoefficientValue = null)
        {
            string message = string.Empty;
            decimal m_decItemPrice = 0;

            ItemPriceVendorPeriodVM m_objItemPriceVendorPeriod = GetItemPriceVendorPeriod(ItemID, ItemPriceVM.RegionID, ItemPriceVM.ProjectID, ItemPriceVM.ClusterID, ItemPriceVM.UnitTypeID, FilterNotIncluded, ref message, ItemVersionChildID, CreatedDate);
            if (m_objItemPriceVendorPeriod != null)
            {
                m_decItemPrice = m_objItemPriceVendorPeriod.Amount;
            }
            else
            {
                if (FilterNotIncluded != ItemPriceVM.Prop.RegionID.Name.ToString() && m_decItemPrice == 0)
                {
                    switch (FilterNotIncluded)
                    {
                        case "ProjectID":
                            FilterNotIncluded = ItemPriceVM.Prop.RegionID.Name.ToString();
                            break;
                        case "ClusterID":
                            FilterNotIncluded = ItemPriceVM.Prop.ProjectID.Name.ToString();
                            break;
                        case "UnitTypeID":
                            FilterNotIncluded = ItemPriceVM.Prop.ClusterID.Name.ToString();
                            break;
                        default:
                            FilterNotIncluded = ItemPriceVM.Prop.UnitTypeID.Name.ToString();
                            break;
                    }
                    m_decItemPrice = GetFromItemPrice(ItemID, ItemPriceVM, CreatedDate, FilterNotIncluded, ItemVersionChildID,null);
                }
            }

            if (CoefficientValue != null)
                m_decItemPrice = m_decItemPrice * (decimal)CoefficientValue;
            return m_decItemPrice;
        }
        private decimal GetFromFormula(string ItemVersionChildID, ItemPriceVM ItemPriceVM, DateTime? CreatedDate)
        {
            string message = string.Empty;
            string m_strReferenceFormula = string.Empty;
            string m_strFormula = string.Empty;
            decimal m_decRefAmount = 0m;
            decimal m_decUnitPriceFormula = 0m;
            string m_strReferenceParameter = string.Empty;
            string m_strParameterPrefix = "X";

            List<string> m_lstReferenceParameters = new List<string>();
            Dictionary<string, decimal> m_dicVariables = new Dictionary<string, decimal>();
            ItemVersionChildVM m_objItemVersionChild = GetItemVersionChild(ItemVersionChildID);

            if (!string.IsNullOrEmpty(m_objItemVersionChild.Formula))
            {
                m_strReferenceFormula = m_objItemVersionChild.Formula.Trim();
                while (m_strReferenceFormula.Contains("[") && m_strReferenceFormula.Contains("]"))
                {
                    m_strReferenceParameter = m_strReferenceFormula.Substring(m_strReferenceFormula.IndexOf("["), m_strReferenceFormula.IndexOf("]", m_strReferenceFormula.IndexOf("["))
                        - m_strReferenceFormula.IndexOf("[") + 1);
                    if (m_strReferenceParameter.Length <= m_strReferenceFormula.Length)
                        m_strReferenceFormula = m_strReferenceFormula.Substring(m_strReferenceFormula.IndexOf("]") + 1).Trim();
                    m_lstReferenceParameters.Add(m_strReferenceParameter.Replace("[", "").Replace("]", "").Trim());
                }
                m_lstReferenceParameters = m_lstReferenceParameters.Distinct().ToList();

                foreach (string m_strParameter in m_lstReferenceParameters)
                {
                    if (m_strParameter != ItemVersionChildID)
                        m_decRefAmount = GetFromFormula(m_strParameter, ItemPriceVM, CreatedDate);
                    if (m_decRefAmount == 0)
                    {
                        ItemVersionChildVM m_objItemVersionChd = GetItemVersionChild(m_strParameter);
                        decimal m_decCoefficient = ItemVersionChildID == m_strParameter ? 1 : m_objItemVersionChd.Coefficient;
                        m_decRefAmount = GetFromItemPrice(string.Empty, ItemPriceVM,CreatedDate, string.Empty, m_strParameter, m_decCoefficient);
                    }
                    m_dicVariables[m_strParameterPrefix + m_strParameter] = m_decRefAmount;
                }
                m_strFormula = m_objItemVersionChild.Formula.Trim().Replace("[", m_strParameterPrefix).Replace("]", string.Empty).Trim();
                m_decUnitPriceFormula = CalculateFormula(m_strFormula, ref message, m_dicVariables, true);
            }
            return m_decUnitPriceFormula;
        }
        private bool FilterItemTypeConfig(string filterKey2, string filterKey4)
        {

            UConfigDA m_objUConfigDA = new UConfigDA();
            m_objUConfigDA.ConnectionStringName = Global.ConnStrConfigName;
            List<object> m_lstFilter = new List<object>();
            Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();

            List<string> m_lstSelect = new List<string>();
            m_lstSelect.Add(ConfigVM.Prop.Key3.MapAlias);

            m_lstFilter.Add(Operator.Equals);
            m_lstFilter.Add(BudgetPlanTemplateStructureVM.Prop.ItemTypeID.Name);
            m_objFilter.Add(ConfigVM.Prop.Key1.Map, m_lstFilter);

            m_lstFilter = new List<object>();
            m_lstFilter.Add(Operator.In);
            m_lstFilter.Add(filterKey2);
            m_objFilter.Add(ConfigVM.Prop.Key2.Map, m_lstFilter);

            m_lstFilter = new List<object>();
            m_lstFilter.Add(Operator.Equals);
            m_lstFilter.Add(filterKey4);
            m_objFilter.Add(ConfigVM.Prop.Key4.Map, m_lstFilter);


            Dictionary<int, DataSet> m_dicUConfigDA = m_objUConfigDA.SelectBC(0, null, true, m_lstSelect, m_objFilter, null, null, null);
            int m_intCount = 0;

            foreach (KeyValuePair<int, DataSet> m_kvpUConfigDA in m_dicUConfigDA)
            {
                m_intCount = m_kvpUConfigDA.Key;
                break;
            }


            return m_intCount > 0;

        }
        private ConfigAHSChildVM GetConfigAHSChlid(string filterKey3)
        {

            UConfigDA m_objUConfigDA = new UConfigDA();
            m_objUConfigDA.ConnectionStringName = Global.ConnStrConfigName;
            List<object> m_lstFilter = new List<object>();
            Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();

            List<string> m_lstSelect = new List<string>();

            m_lstSelect.Add(ConfigVM.Prop.Key2.MapAlias);
            m_lstSelect.Add(ConfigVM.Prop.Key3.MapAlias);

            m_lstFilter.Add(Operator.Equals);
            m_lstFilter.Add(BudgetPlanTemplateStructureVM.Prop.ItemTypeID.Name);
            m_objFilter.Add(ConfigVM.Prop.Key1.Map, m_lstFilter);

            m_lstFilter = new List<object>();
            m_lstFilter.Add(Operator.Equals);
            m_lstFilter.Add(filterKey3);
            m_objFilter.Add(ConfigVM.Prop.Key3.Map, m_lstFilter);

            ConfigAHSChildVM m_objConfigAHSChildVM = new ConfigAHSChildVM();
            Dictionary<int, DataSet> m_dicUConfigDA = m_objUConfigDA.SelectBC(0, null, false, m_lstSelect, m_objFilter, null, null, null);
            if (m_objUConfigDA.Message == string.Empty)
            {
                foreach (DataRow m_dtRow in m_dicUConfigDA[0].Tables[0].Rows)
                {
                    m_objConfigAHSChildVM.ItemTypeID = m_dtRow[ConfigVM.Prop.Key3.Name].ToString();
                    if (m_dtRow[ConfigVM.Prop.Key2.Name].ToString() == ConfigAHSChildVM.Prop.HasAlternativeItem.Desc)
                        m_objConfigAHSChildVM.HasAlternativeItem = true;
                    else if (m_dtRow[ConfigVM.Prop.Key2.Name].ToString() == ConfigAHSChildVM.Prop.HasCoefficient.Desc)
                        m_objConfigAHSChildVM.HasCoefficient = true;
                    else if (m_dtRow[ConfigVM.Prop.Key2.Name].ToString() == ConfigAHSChildVM.Prop.HasFormula.Desc)
                        m_objConfigAHSChildVM.HasFormula = true;
                }
            }

            return m_objConfigAHSChildVM;

        }
        private ItemPriceVendorPeriodVM GetItemPriceVendorPeriod(string ItemID, string RegionID, string ProjectID, string ClusterID, string UnitTypeID, string FilterNotIncluded, ref string message, string ItemVersionChildID = "", DateTime? CreatedDate=null)
        {

            ItemPriceVendorPeriodVM m_objItemPriceVendorPeriodVM = new ItemPriceVendorPeriodVM();
            DItemPriceVendorPeriodDA m_objDItemPriceVendorPeriodDA = new DItemPriceVendorPeriodDA();
            m_objDItemPriceVendorPeriodDA.ConnectionStringName = Global.ConnStrConfigName;

            List<string> m_lstSelect = new List<string>();
            m_lstSelect.Add(ItemPriceVendorPeriodVM.Prop.ItemPriceID.MapAlias);
            m_lstSelect.Add(ItemPriceVendorPeriodVM.Prop.CurrencyID.MapAlias);
            m_lstSelect.Add(ItemPriceVendorPeriodVM.Prop.Amount.MapAlias);

            Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();

            List<object> m_lstFilter = new List<object>();
            if (!string.IsNullOrEmpty(ItemVersionChildID))
            {

                ItemID = GetItemVersionChild(ItemVersionChildID).ChildItemID;
            }

            m_lstFilter.Add(Operator.Equals);
            m_lstFilter.Add(ItemID);
            m_objFilter.Add(ItemPriceVM.Prop.ItemID.Map, m_lstFilter);


            //if (!string.IsNullOrEmpty(RegionID))
            //{
            m_lstFilter = new List<object>();
            m_lstFilter.Add(Operator.Equals);

            if (RegionID == null)
                RegionID = string.Empty;

            m_lstFilter.Add(RegionID);
            m_objFilter.Add(ItemPriceVM.Prop.RegionID.Map, m_lstFilter);
            //}

            if (!string.IsNullOrEmpty(ProjectID) && FilterNotIncluded != ItemPriceVM.Prop.ProjectID.Name)
            {

                if (!string.IsNullOrEmpty(ClusterID) && FilterNotIncluded != ItemPriceVM.Prop.ClusterID.Name)
                {

                    if (!string.IsNullOrEmpty(UnitTypeID) && FilterNotIncluded != ItemPriceVM.Prop.UnitTypeID.Name)
                    {
                        m_lstFilter = new List<object>();
                        m_lstFilter.Add(Operator.Equals);
                        m_lstFilter.Add(UnitTypeID);
                        m_objFilter.Add(ItemPriceVM.Prop.UnitTypeID.Map, m_lstFilter);
                    }

                    m_lstFilter = new List<object>();
                    m_lstFilter.Add(Operator.Equals);
                    m_lstFilter.Add(ClusterID);
                    m_objFilter.Add(ItemPriceVM.Prop.ClusterID.Map, m_lstFilter);
                }
                m_lstFilter = new List<object>();
                m_lstFilter.Add(Operator.Equals);
                m_lstFilter.Add(ProjectID);
                m_objFilter.Add(ItemPriceVM.Prop.ProjectID.Map, m_lstFilter);

            }

            m_lstFilter = new List<object>();
            m_lstFilter.Add(Operator.In);
            m_lstFilter.Add(1);
            m_objFilter.Add(ItemPriceVendorVM.Prop.IsDefault.Map, m_lstFilter);

            string m_strCreatedDate = CreatedDate == null ? DateTime.Now.Date.ToString(Global.SqlDateFormat) : CreatedDate.Value.Date.ToString(Global.SqlDateFormat);

            m_lstFilter = new List<object>();
            m_lstFilter.Add(Operator.LessThanEqual);
            m_lstFilter.Add(m_strCreatedDate);
            m_objFilter.Add(ItemPriceVendorPeriodVM.Prop.ValidFrom.Map, m_lstFilter);

            m_lstFilter = new List<object>();
            m_lstFilter.Add(Operator.GreaterThanEqual);
            m_lstFilter.Add(m_strCreatedDate);
            m_objFilter.Add(ItemPriceVendorPeriodVM.Prop.ValidTo.Map, m_lstFilter);

            Dictionary<string, OrderDirection> m_dicOrderBy = new Dictionary<string, OrderDirection>();
            m_dicOrderBy.Add(ItemPriceVM.Prop.ItemID.Map, OrderDirection.Ascending);

            Dictionary<int, DataSet> m_dicDItemPriceVendorPeriodDA = m_objDItemPriceVendorPeriodDA.SelectBC(0, 1, false, m_lstSelect, m_objFilter, null, null, m_dicOrderBy);
            if (m_objDItemPriceVendorPeriodDA.Success)
            {
                m_objItemPriceVendorPeriodVM =
                (from DataRow m_drDItemPriceVendorPeriodDA in m_dicDItemPriceVendorPeriodDA[0].Tables[0].Rows
                 select new ItemPriceVendorPeriodVM()
                 {
                     ItemPriceID = m_drDItemPriceVendorPeriodDA[ItemPriceVendorPeriodVM.Prop.ItemPriceID.Name].ToString(),
                     Amount = (decimal)m_drDItemPriceVendorPeriodDA[ItemPriceVendorPeriodVM.Prop.Amount.Name],
                     CurrencyID = m_drDItemPriceVendorPeriodDA[ItemPriceVendorPeriodVM.Prop.CurrencyID.Name].ToString()
                 }).FirstOrDefault();
            }
            else
                message = m_objDItemPriceVendorPeriodDA.Message;

            return m_objItemPriceVendorPeriodVM;

        }
        private ItemVersionChildVM GetFormula(string ItemVersionChildID)
        {

            DItemVersionChildDA m_objItemVersionChildDA = new DItemVersionChildDA();
            m_objItemVersionChildDA.ConnectionStringName = Global.ConnStrConfigName;
            object m_objDBConnection = m_objItemVersionChildDA.BeginConnection();

            ItemVersionChildVM m_objItemVersionChildVM = new ItemVersionChildVM();
            Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();

            List<object> m_lstFilter = new List<object>();
            m_lstFilter.Add(Operator.Equals);
            m_lstFilter.Add(ItemVersionChildID);
            m_objFilter.Add(ItemVersionChildVM.Prop.ItemVersionChildID.Map, m_lstFilter);

            bool m_boolIsCount = false;
            List<string> m_lstSelect = new List<string>();
            m_lstSelect.Add(ItemVersionChildVM.Prop.ItemVersionChildID.MapAlias);
            m_lstSelect.Add(ItemVersionChildVM.Prop.ChildItemID.MapAlias);
            m_lstSelect.Add(ItemVersionChildVM.Prop.ChildVersion.MapAlias);
            m_lstSelect.Add(ItemVersionChildVM.Prop.Sequence.MapAlias);
            m_lstSelect.Add(ItemVersionChildVM.Prop.Formula.MapAlias);

            Dictionary<int, DataSet> m_dicMItemVersionDA = m_objItemVersionChildDA.SelectBC(0, 1, m_boolIsCount, m_lstSelect, m_objFilter, null, null, null, null);

            if (m_objItemVersionChildDA.Message == "")
            {

                DataRow m_drMItemVersionChildDA = m_dicMItemVersionDA[0].Tables[0].Rows[0];
                m_objItemVersionChildVM = new ItemVersionChildVM()
                {
                    ItemVersionChildID = m_drMItemVersionChildDA[ItemVersionChildVM.Prop.ItemVersionChildID.Name].ToString(),
                    ChildItemID = m_drMItemVersionChildDA[ItemVersionChildVM.Prop.ChildItemID.Name].ToString(),
                    ChildVersion = (int)m_drMItemVersionChildDA[ItemVersionChildVM.Prop.ChildVersion.Name],
                    Sequence = (int)m_drMItemVersionChildDA[ItemVersionChildVM.Prop.Sequence.Name],
                    Formula = m_drMItemVersionChildDA[ItemVersionChildVM.Prop.Formula.Name].ToString(),
                    Coefficient = decimal.Parse(m_drMItemVersionChildDA[ItemVersionChildVM.Prop.Coefficient.Name].ToString())
                };
            }

            return m_objItemVersionChildVM;
        }
        private ItemVersionChildVM GetItemVersionChild(string ItemVersionChildID)
        {
            #region DItemVersionChild
            DItemVersionChildDA m_objDItemVersionChildDA = new DItemVersionChildDA();
            m_objDItemVersionChildDA.ConnectionStringName = Global.ConnStrConfigName;

            Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();

            if (!string.IsNullOrEmpty(ItemVersionChildID))
            {
                List<object> m_lstFilter = new List<object>();
                m_lstFilter.Add(Operator.Equals);
                m_lstFilter.Add(ItemVersionChildID);
                m_objFilter.Add(ItemVersionChildVM.Prop.ItemVersionChildID.Map, m_lstFilter);
            }

            ItemVersionChildVM m_objItemVersionChildVM = new ItemVersionChildVM();

            List<string> m_lstSelect = new List<string>();
            m_lstSelect.Add(ItemVersionChildVM.Prop.ItemID.MapAlias);
            m_lstSelect.Add(ItemVersionChildVM.Prop.ItemDesc.MapAlias);
            m_lstSelect.Add(ItemVersionChildVM.Prop.ItemTypeDesc.MapAlias);
            m_lstSelect.Add(ItemVersionChildVM.Prop.ItemGroupDesc.MapAlias);
            m_lstSelect.Add(ItemVersionChildVM.Prop.Version.MapAlias);
            m_lstSelect.Add(ItemVersionChildVM.Prop.VersionDesc.MapAlias);
            m_lstSelect.Add(ItemVersionChildVM.Prop.ItemTypeID.MapAlias);
            m_lstSelect.Add(ItemVersionChildVM.Prop.UoMDesc.MapAlias);
            m_lstSelect.Add(ItemVersionChildVM.Prop.ChildItemID.MapAlias);
            m_lstSelect.Add(ItemVersionChildVM.Prop.ChildItemDesc.MapAlias);
            m_lstSelect.Add(ItemVersionChildVM.Prop.ChildVersion.MapAlias);
            m_lstSelect.Add(ItemVersionChildVM.Prop.Sequence.MapAlias);
            m_lstSelect.Add(ItemVersionChildVM.Prop.Formula.MapAlias);
            m_lstSelect.Add(ItemVersionChildVM.Prop.Coefficient.MapAlias);

            Dictionary<int, DataSet> m_dicDItemVersionChildDA = m_objDItemVersionChildDA.SelectBC(0, 1, false, m_lstSelect, m_objFilter, null, null, null, null);
            if (m_objDItemVersionChildDA.Message == string.Empty)
            {
                DataRow m_drDItemVersionChildDA = m_dicDItemVersionChildDA[0].Tables[0].Rows[0];
                m_objItemVersionChildVM = new ItemVersionChildVM()
                {
                    ItemID = m_drDItemVersionChildDA[ItemVersionChildVM.Prop.ItemID.Name].ToString(),
                    ItemDesc = m_drDItemVersionChildDA[ItemVersionChildVM.Prop.ItemDesc.Name].ToString(),
                    ItemTypeDesc = m_drDItemVersionChildDA[ItemVersionChildVM.Prop.ItemTypeDesc.Name].ToString(),
                    ItemGroupDesc = m_drDItemVersionChildDA[ItemVersionChildVM.Prop.ItemGroupDesc.Name].ToString(),
                    Version = (int)m_drDItemVersionChildDA[ItemVersionChildVM.Prop.Version.Name],
                    VersionDesc = m_drDItemVersionChildDA[ItemVersionChildVM.Prop.VersionDesc.Name].ToString(),
                    UoMDesc = m_drDItemVersionChildDA[ItemVersionChildVM.Prop.UoMDesc.Name].ToString(),
                    ItemTypeID = m_drDItemVersionChildDA[ItemVersionChildVM.Prop.ItemTypeID.Name].ToString(),
                    Coefficient = decimal.Parse(m_drDItemVersionChildDA[ItemVersionChildVM.Prop.Coefficient.Name].ToString()),
                    Formula = m_drDItemVersionChildDA[ItemVersionChildVM.Prop.Formula.Name].ToString(),
                    ChildItemID = m_drDItemVersionChildDA[ItemVersionChildVM.Prop.ChildItemID.Name].ToString(),
                    ChildItemDesc = m_drDItemVersionChildDA[ItemVersionChildVM.Prop.ItemDesc.Name].ToString(),
                    ChildVersion = int.Parse(m_drDItemVersionChildDA[ItemVersionChildVM.Prop.ChildVersion.Name].ToString()),
                    Sequence = int.Parse(m_drDItemVersionChildDA[ItemVersionChildVM.Prop.Sequence.Name].ToString()),
                };
            }

            #endregion
            return m_objItemVersionChildVM;
        }
        #endregion
    }
}