﻿using com.SML.Lib.Common;
using com.SML.BIGTRONS.DataAccess;
using com.SML.BIGTRONS.Enum;
using com.SML.BIGTRONS.Models;
using com.SML.BIGTRONS.ViewModels;
using Ext.Net;
using Ext.Net.MVC;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using XMVC = Ext.Net.MVC;

namespace com.SML.BIGTRONS.Controllers
{
    public class VendorController : BaseController
    {
        private readonly string title = "Vendor";
        private readonly string dataSessionName = "FormData";

        #region Public Action

        public ActionResult Index()
        {
            base.Initialize();
            return View();
        }

        public ActionResult List()
        {
            Global.HasAccess = GetHasAccess();
            if (!Global.HasAccess.Read)
                return this.Direct(false, General.EnumDesc(MessageLib.NotAuthorized));

            if (Session[dataSessionName] != null)
                Session[dataSessionName] = null;

            this.GetCmp<Container>(General.EnumDesc(Params.PageContainer)).ActiveIndex = 0;
            return new XMVC.PartialViewResult
            {
                ClearContainer = true,
                ContainerId = General.EnumName(Params.HomePage),
                RenderMode = RenderMode.AddTo,
                ViewName = "_List",
                WrapByScriptTag = false
            };
        }

        public ActionResult Read(StoreRequestParameters parameters)
        {
            MVendorDA m_objMVendorDA = new MVendorDA();
            m_objMVendorDA.ConnectionStringName = Global.ConnStrConfigName;

            int m_intSkip = parameters.Start;
            int m_intLength = parameters.Limit;
            bool m_boolIsCount = true;

            FilterHeaderConditions m_fhcMVendor = new FilterHeaderConditions(this.Request.Params[General.EnumDesc(Params.FilterHeader)]);
            Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();

            foreach (FilterHeaderCondition m_fhcFilter in m_fhcMVendor.Conditions)
            {
                string m_strDataIndex = m_fhcFilter.DataIndex;
                string m_strConditionOperator = m_fhcFilter.Operator;
                object m_objValue = Global.GetFilterConditionValue(m_fhcFilter);

                if (m_strDataIndex != string.Empty)
                {
                    m_strDataIndex = VendorVM.Prop.Map(m_strDataIndex, false);
                    List<object> m_lstFilter = new List<object>();
                    if (m_strConditionOperator != Global.OpComparation)
                    {
                        m_lstFilter.Add(Global.GetOperator(m_strConditionOperator));
                        m_lstFilter.Add(m_objValue);
                        m_objFilter.Add(m_strDataIndex, m_lstFilter);
                    }
                    else
                    {
                        object m_objStart = null;
                        object m_objEnd = null;
                        foreach (KeyValuePair<string, object> m_kvpFilterDetail in (List<KeyValuePair<string, object>>)m_objValue)
                        {
                            switch (m_kvpFilterDetail.Key)
                            {
                                case Global.OpLessThan:
                                case Global.OpLessThanEqual:
                                    m_objEnd = m_kvpFilterDetail.Value;
                                    break;
                                case Global.OpGreaterThan:
                                case Global.OpGreaterThanEqual:
                                    m_objStart = m_kvpFilterDetail.Value;
                                    break;
                            }
                        }
                        if (m_objStart != null || m_objEnd != null)
                            m_lstFilter.Add((m_objStart != null ? (m_objEnd != null ? Operator.Between
                                : Operator.GreaterThanEqual) : (m_objEnd != null ? Operator.LessThanEqual
                                : Operator.None)));
                        m_lstFilter.Add(m_objStart != null ? m_objStart : "");
                        m_lstFilter.Add(m_objEnd != null ? m_objEnd : "");
                        m_objFilter.Add(m_strDataIndex, m_lstFilter);
                    }
                }
            }
            Dictionary<int, DataSet> m_dicMVendorDA = m_objMVendorDA.SelectBC(m_intSkip, m_intLength, m_boolIsCount, null, m_objFilter, null, null, null, null);
            int m_intCount = 0;

            foreach (KeyValuePair<int, DataSet> m_kvpVendorBL in m_dicMVendorDA)
            {
                m_intCount = m_kvpVendorBL.Key;
                break;
            }

            List<VendorVM> m_lstVendorVM = new List<VendorVM>();
            if (m_intCount > 0)
            {
                m_boolIsCount = false;
                List<string> m_lstSelect = new List<string>();
                m_lstSelect.Add(VendorVM.Prop.VendorID.MapAlias);
                m_lstSelect.Add(VendorVM.Prop.VendorDesc.MapAlias);
                m_lstSelect.Add(VendorVM.Prop.VendorCategoryDesc.MapAlias);
                m_lstSelect.Add(VendorVM.Prop.VendorSubcategoryDesc.MapAlias);
                m_lstSelect.Add(VendorVM.Prop.Address.MapAlias);
                m_lstSelect.Add(VendorVM.Prop.Phone.MapAlias);
                m_lstSelect.Add(VendorVM.Prop.Email.MapAlias);

                Dictionary<string, OrderDirection> m_dicOrder = new Dictionary<string, OrderDirection>();
                foreach (DataSorter m_dtsOrder in parameters.Sort)
                    m_dicOrder.Add(VendorVM.Prop.Map(m_dtsOrder.Property.Substring(m_dtsOrder.Property.LastIndexOf(".") + 1)), General.EnumFromDesc<OrderDirection>(General.EnumName(m_dtsOrder.Direction)));

                m_dicMVendorDA = m_objMVendorDA.SelectBC(m_intSkip, m_intLength, m_boolIsCount, m_lstSelect, m_objFilter, null, null, m_dicOrder, null);
                if (m_objMVendorDA.Message == string.Empty)
                {
                    m_lstVendorVM = (
                        from DataRow m_drMVendorDA in m_dicMVendorDA[0].Tables[0].Rows
                        select new VendorVM()
                        {
                            VendorID = m_drMVendorDA[VendorVM.Prop.VendorID.Name].ToString(),
                            VendorDesc = m_drMVendorDA[VendorVM.Prop.VendorDesc.Name].ToString(),
                            VendorCategoryDesc = m_drMVendorDA[VendorVM.Prop.VendorCategoryDesc.Name].ToString(),
                            VendorSubcategoryDesc = m_drMVendorDA[VendorVM.Prop.VendorSubcategoryDesc.Name].ToString(),
                            Address = m_drMVendorDA[VendorVM.Prop.Address.Name].ToString(),
                            Phone = m_drMVendorDA[VendorVM.Prop.Phone.Name].ToString(),
                            Email = m_drMVendorDA[VendorVM.Prop.Email.Name].ToString(),
                        }
                    ).ToList();
                }
            }
            return this.Store(m_lstVendorVM, m_intCount);
        }

        public ActionResult ReadBrowse(StoreRequestParameters parameters)
        {
            MVendorDA m_objMVendorDA = new MVendorDA();
            m_objMVendorDA.ConnectionStringName = Global.ConnStrConfigName;

            int m_intSkip = parameters.Start;
            int m_intLength = parameters.Limit;
            bool m_boolIsCount = true;

            FilterHeaderConditions m_fhcMVendor = new FilterHeaderConditions(this.Request.Params[General.EnumDesc(Params.FilterHeader)]);
            Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();

            foreach (FilterHeaderCondition m_fhcFilter in m_fhcMVendor.Conditions)
            {
                string m_strDataIndex = m_fhcFilter.DataIndex;
                string m_strConditionOperator = m_fhcFilter.Operator;
                object m_objValue = Global.GetFilterConditionValue(m_fhcFilter);

                if (m_strDataIndex != string.Empty)
                {
                    m_strDataIndex = VendorVM.Prop.Map(m_strDataIndex, false);
                    List<object> m_lstFilter = new List<object>();
                    if (m_strConditionOperator != Global.OpComparation)
                    {
                        m_lstFilter.Add(Global.GetOperator(m_strConditionOperator));
                        m_lstFilter.Add(m_objValue);
                        m_objFilter.Add(m_strDataIndex, m_lstFilter);
                    }
                    else
                    {
                        object m_objStart = null;
                        object m_objEnd = null;
                        foreach (KeyValuePair<string, object> m_kvpFilterDetail in (List<KeyValuePair<string, object>>)m_objValue)
                        {
                            switch (m_kvpFilterDetail.Key)
                            {
                                case Global.OpLessThan:
                                case Global.OpLessThanEqual:
                                    m_objEnd = m_kvpFilterDetail.Value;
                                    break;
                                case Global.OpGreaterThan:
                                case Global.OpGreaterThanEqual:
                                    m_objStart = m_kvpFilterDetail.Value;
                                    break;
                            }
                        }
                        if (m_objStart != null || m_objEnd != null)
                            m_lstFilter.Add((m_objStart != null ? (m_objEnd != null ? Operator.Between
                                : Operator.GreaterThanEqual) : (m_objEnd != null ? Operator.LessThanEqual
                                : Operator.None)));
                        m_lstFilter.Add(m_objStart != null ? m_objStart : "");
                        m_lstFilter.Add(m_objEnd != null ? m_objEnd : "");
                        m_objFilter.Add(m_strDataIndex, m_lstFilter);
                    }
                }
            }
            Dictionary<int, DataSet> m_dicMVendorDA = m_objMVendorDA.SelectBC(m_intSkip, m_intLength, m_boolIsCount, null, m_objFilter, null, null, null, null);
            int m_intCount = 0;

            foreach (KeyValuePair<int, DataSet> m_kvpVendorBL in m_dicMVendorDA)
            {
                m_intCount = m_kvpVendorBL.Key;
                break;
            }

            List<VendorVM> m_lstVendorVM = new List<VendorVM>();
            if (m_intCount > 0)
            {
                m_boolIsCount = false;
                List<string> m_lstSelect = new List<string>();
                m_lstSelect.Add(VendorVM.Prop.VendorID.MapAlias);
                m_lstSelect.Add(VendorVM.Prop.VendorDesc.MapAlias);
                m_lstSelect.Add(VendorVM.Prop.VendorCategoryDesc.MapAlias);
                m_lstSelect.Add(VendorVM.Prop.VendorSubcategoryDesc.MapAlias);

                Dictionary<string, OrderDirection> m_dicOrder = new Dictionary<string, OrderDirection>();
                foreach (DataSorter m_dtsOrder in parameters.Sort)
                    m_dicOrder.Add(VendorVM.Prop.Map(m_dtsOrder.Property.Substring(m_dtsOrder.Property.LastIndexOf(".") + 1)), General.EnumFromDesc<OrderDirection>(General.EnumName(m_dtsOrder.Direction)));

                m_dicMVendorDA = m_objMVendorDA.SelectBC(m_intSkip, m_intLength, m_boolIsCount, m_lstSelect, m_objFilter, null, null, m_dicOrder, null);
                if (m_objMVendorDA.Message == string.Empty)
                {
                    m_lstVendorVM = (
                        from DataRow m_drMVendorDA in m_dicMVendorDA[0].Tables[0].Rows
                        select new VendorVM()
                        {
                            VendorID = m_drMVendorDA[VendorVM.Prop.VendorID.Name].ToString(),
                            VendorDesc = m_drMVendorDA[VendorVM.Prop.VendorDesc.Name].ToString(),
                            VendorCategoryDesc = m_drMVendorDA[VendorVM.Prop.VendorCategoryDesc.Name].ToString(),
                            VendorSubcategoryDesc = m_drMVendorDA[VendorVM.Prop.VendorSubcategoryDesc.Name].ToString()
                        }
                    ).ToList();
                }
            }
            return this.Store(m_lstVendorVM, m_intCount);
        }

        public ActionResult Home()
        {
            this.GetCmp<Container>(General.EnumDesc(Params.PageContainer)).ActiveIndex = 0;
            return this.Direct();
        }

        public ActionResult Add(string Caller)
        {
            Global.HasAccess = GetHasAccess();
            if (!Global.HasAccess.Add)
                return this.Direct(false, General.EnumDesc(MessageLib.NotAuthorized));

            VendorVM m_objVendorVM = new VendorVM();
            ViewDataDictionary m_vddVendor = new ViewDataDictionary();
            m_vddVendor.Add(General.EnumDesc(Params.Caller), Caller);
            m_vddVendor.Add(General.EnumDesc(Params.Action), General.EnumDesc(Buttons.ButtonAdd));
            if (Caller == General.EnumDesc(Buttons.ButtonDetail))
            {
                NameValueCollection m_nvcParams = this.Request.Params;
                Dictionary<string, object> m_dicSelectedRow = GetFormData(m_nvcParams);
                Session[dataSessionName] = JSON.Serialize(m_dicSelectedRow);
            }

            this.GetCmp<Container>(General.EnumDesc(Params.PageContainer)).ActiveIndex = 1;
            return new XMVC.PartialViewResult
            {
                ClearContainer = true,
                ContainerId = General.EnumName(Params.PageOne),
                Model = m_objVendorVM,
                RenderMode = RenderMode.AddTo,
                ViewData = m_vddVendor,
                ViewName = "_Form",
                WrapByScriptTag = false
            };
        }

        public ActionResult Detail(string Caller, string Selected)
        {
            Global.HasAccess = GetHasAccess();
            if (!Global.HasAccess.Read)
                return this.Direct(false, General.EnumDesc(MessageLib.NotAuthorized));

            VendorVM m_objVendorVM = new VendorVM();
            string m_strMessage = string.Empty;
            Dictionary<string, object> m_dicSelectedRow = new Dictionary<string, object>();
            if (Caller == General.EnumDesc(Buttons.ButtonCancel))
            {
                if (Session[dataSessionName] != null)
                {
                    try
                    {
                        m_dicSelectedRow = JSON.Deserialize<Dictionary<string, object>>(Session[dataSessionName].ToString());
                    }
                    catch (Exception ex)
                    {
                        m_strMessage = ex.Message;
                    }
                    Session[dataSessionName] = null;
                }
                else
                    m_strMessage = General.EnumDesc(MessageLib.Unknown);
            }
            else if (Caller == General.EnumDesc(Buttons.ButtonList))
                m_dicSelectedRow = JSON.Deserialize<Dictionary<string, object>>(Selected);
            else if (Caller == General.EnumDesc(Buttons.ButtonSave))
            {
                NameValueCollection m_nvcParams = this.Request.Params;
                m_dicSelectedRow = GetFormData(m_nvcParams);
            }

            if (m_dicSelectedRow.Count > 0)
                m_objVendorVM = GetSelectedData(m_dicSelectedRow, ref m_strMessage);
            if (m_strMessage != string.Empty)
            {
                Global.ShowErrorAlert(title, m_strMessage);
                return this.Direct();
            }

            ViewDataDictionary m_vddWorkCenter = new ViewDataDictionary();
            m_vddWorkCenter.Add(General.EnumDesc(Params.Action), General.EnumDesc(Buttons.ButtonDetail));
            this.GetCmp<Container>(General.EnumDesc(Params.PageContainer)).ActiveIndex = 1;
            return new XMVC.PartialViewResult
            {
                ClearContainer = true,
                ContainerId = General.EnumName(Params.PageOne),
                Model = m_objVendorVM,
                RenderMode = RenderMode.AddTo,
                ViewData = m_vddWorkCenter,
                ViewName = "_Form",
                WrapByScriptTag = false
            };
        }

        public ActionResult Update(string Caller, string Selected)
        {
            Global.HasAccess = GetHasAccess();
            if (!Global.HasAccess.Update)
                return this.Direct(false, General.EnumDesc(MessageLib.NotAuthorized));

            Dictionary<string, object> m_dicSelectedRow = new Dictionary<string, object>();
            if (Caller == General.EnumDesc(Buttons.ButtonList))
            {
                m_dicSelectedRow = JSON.Deserialize<Dictionary<string, object>>(Selected);
            }
            else if (Caller == General.EnumDesc(Buttons.ButtonDetail))
            {
                NameValueCollection m_nvcParams = this.Request.Params;
                m_dicSelectedRow = GetFormData(m_nvcParams);
                Session[dataSessionName] = JSON.Serialize(m_dicSelectedRow);
            }

            string m_strMessage = string.Empty;
            VendorVM m_objVendorVM = new VendorVM();
            if (m_dicSelectedRow.Count > 0)
                m_objVendorVM = GetSelectedData(m_dicSelectedRow, ref m_strMessage);
            if (m_strMessage != string.Empty)
            {
                Global.ShowErrorAlert(title, m_strMessage);
                return this.Direct();
            }

            ViewDataDictionary m_vddVendor = new ViewDataDictionary();
            m_vddVendor.Add(General.EnumDesc(Params.Caller), Caller);
            m_vddVendor.Add(General.EnumDesc(Params.Action), General.EnumDesc(Buttons.ButtonUpdate));
            this.GetCmp<Container>(General.EnumDesc(Params.PageContainer)).ActiveIndex = 1;
            return new XMVC.PartialViewResult
            {
                ClearContainer = true,
                ContainerId = General.EnumName(Params.PageOne),
                Model = m_objVendorVM,
                RenderMode = RenderMode.AddTo,
                ViewData = m_vddVendor,
                ViewName = "_Form",
                WrapByScriptTag = false
            };
        }

        public ActionResult Delete(string Selected)
        {
            if (!HasAccess(General.GetVariableName(() => new HasAccessVM().Delete)))
                return this.Direct(false, General.EnumDesc(MessageLib.NotAuthorized));

            List<VendorVM> m_lstSelectedRow = new List<VendorVM>();
            m_lstSelectedRow = JSON.Deserialize<List<VendorVM>>(Selected);

            MVendorDA m_objMVendorDA = new MVendorDA();
            m_objMVendorDA.ConnectionStringName = Global.ConnStrConfigName;
            List<string> m_lstMessage = new List<string>();

            try
            {
                foreach (VendorVM m_objVendorVM in m_lstSelectedRow)
                {
                    List<string> m_lstKey = new List<string>();
                    Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();
                    PropertyInfo[] m_arrPifVendorVM = m_objVendorVM.GetType().GetProperties();

                    foreach (PropertyInfo m_pifVendorVM in m_arrPifVendorVM)
                    {
                        string m_strFieldName = m_pifVendorVM.Name;
                        object m_objFieldValue = m_pifVendorVM.GetValue(m_objVendorVM);
                        if (m_objVendorVM.IsKey(m_strFieldName))
                        {
                            m_lstKey.Add(m_objFieldValue.ToString());
                            List<object> m_lstFilter = new List<object>();
                            m_lstFilter.Add(Operator.Equals);
                            m_lstFilter.Add(m_objFieldValue);
                            m_objFilter.Add(VendorVM.Prop.Map(m_strFieldName, false), m_lstFilter);
                        }
                        else break;
                    }

                    m_objMVendorDA.DeleteBC(m_objFilter, false);
                    if (m_objMVendorDA.Message != string.Empty)
                        m_lstMessage.Add("[" + string.Join(Global.OneLineSeparated, m_lstKey) + "] " + m_objMVendorDA.Message);
                }
            }
            catch (Exception ex)
            {
                m_lstMessage.Add(ex.Message);
            }
            if (m_lstMessage.Count <= 0)
                Global.ShowInfoAlert(title, General.EnumDesc(MessageLib.Deleted));
            else
                Global.ShowErrorAlert(title, string.Join(Global.NewLineSeparated, m_lstMessage));

            return this.Direct();
        }

        public ActionResult Browse(string ControlVendorID, string ControlVendorDesc, string FilterVendorID = "", string FilterVendorDesc = "")
        {
            if (!HasAccess(General.GetVariableName(() => new HasAccessVM().Read)))
                return this.Direct(false, General.EnumDesc(MessageLib.NotAuthorized));

            ViewDataDictionary m_vddVendor = new ViewDataDictionary();
            m_vddVendor.Add("Control" + VendorVM.Prop.VendorID.Name, ControlVendorID);
            m_vddVendor.Add("Control" + VendorVM.Prop.VendorDesc.Name, ControlVendorDesc);
            m_vddVendor.Add(VendorVM.Prop.VendorID.Name, FilterVendorID);
            m_vddVendor.Add(VendorVM.Prop.VendorDesc.Name, FilterVendorDesc);

            return new XMVC.PartialViewResult
            {
                RenderMode = RenderMode.Auto,
                WrapByScriptTag = false,
                ViewData = m_vddVendor,
                ViewName = "../Vendor/_Browse"
            };
        }

        public ActionResult Save(string Action)
        {
            if (!(Action == General.EnumDesc(Buttons.ButtonAdd) ? HasAccess(General.GetVariableName(() => new HasAccessVM().Add))
                : HasAccess(General.GetVariableName(() => new HasAccessVM().Update))))
                return this.Direct(false, General.EnumDesc(MessageLib.NotAuthorized));

            List<string> m_lstMessage = new List<string>();
            MVendorDA m_objMVendorDA = new MVendorDA();
            m_objMVendorDA.ConnectionStringName = Global.ConnStrConfigName;
            try
            {
                string m_strVendorID = this.Request.Params[VendorVM.Prop.VendorID.Name];
                string m_strVendorSubcategoryID = this.Request.Params[VendorSubcategoryVM.Prop.VendorSubcategoryID.Name];
                string m_strFirstName = this.Request.Params[VendorVM.Prop.FirstName.Name];
                string m_strLastName = this.Request.Params[VendorVM.Prop.LastName.Name];
                string m_strCity = this.Request.Params[VendorVM.Prop.City.Name];
                string m_strStreet = this.Request.Params[VendorVM.Prop.Street.Name];
                string m_strPostal = this.Request.Params[VendorVM.Prop.Postal.Name];
                string m_strPhone = this.Request.Params[VendorVM.Prop.Phone.Name];
                string m_strEmail = this.Request.Params[VendorVM.Prop.Email.Name];
                string m_strIDNo = this.Request.Params[VendorVM.Prop.IDNo.Name];
                string m_strNPWP = this.Request.Params[VendorVM.Prop.NPWP.Name];

                m_lstMessage = IsSaveValid(Action, m_strVendorID, m_strVendorSubcategoryID, m_strFirstName,
                    m_strLastName, m_strCity, m_strStreet, m_strPostal, m_strPhone, m_strEmail, m_strIDNo, m_strNPWP);
                if (m_lstMessage.Count <= 0)
                {
                    MVendor m_objMVendor = new MVendor();
                    m_objMVendor.VendorID = m_strVendorID;
                    m_objMVendorDA.Data = m_objMVendor;

                    if (Action != General.EnumDesc(Buttons.ButtonAdd))
                        m_objMVendorDA.Select();

                    m_objMVendor.FirstName = m_strFirstName;
                    m_objMVendor.LastName = m_strLastName;
                    m_objMVendor.City = m_strCity;
                    m_objMVendor.Street = m_strStreet;
                    m_objMVendor.Postal = m_strPostal;
                    m_objMVendor.Phone = m_strPhone;
                    m_objMVendor.Email = m_strEmail;
                    m_objMVendor.IDNo = m_strIDNo;
                    m_objMVendor.NPWP = m_strNPWP;
                    m_objMVendor.VendorSubcategoryID = m_strVendorSubcategoryID;

                    if (Action == General.EnumDesc(Buttons.ButtonAdd))
                        m_objMVendorDA.Insert(false);
                    else
                        m_objMVendorDA.Update(false);

                    if (!m_objMVendorDA.Success || m_objMVendorDA.Message != string.Empty)
                        m_lstMessage.Add(m_objMVendorDA.Message);
                }
            }
            catch (Exception ex)
            {
                m_lstMessage.Add(ex.Message);
            }
            if (m_lstMessage.Count <= 0)
            {
                Global.ShowInfoAlert(title, General.EnumDesc(Action == General.EnumDesc(Buttons.ButtonAdd) ? MessageLib.Added : MessageLib.Updated));
                return Detail(General.EnumDesc(Buttons.ButtonSave), null);
            }
            Global.ShowErrorAlert(title, string.Join(Global.NewLineSeparated, m_lstMessage));
            return this.Direct(true);
        }

        #endregion

        #region Direct Method

        public ActionResult GetVendor(string ControlVendorID, string ControlVendorDesc, string FilterVendorID, string FilterVendorDesc, bool Exact = false)
        {
            try
            {
                Dictionary<int, List<VendorVM>> m_dicVendorData = GetVendorData(true, FilterVendorID, FilterVendorDesc);
                KeyValuePair<int, List<VendorVM>> m_kvpVendorVM = m_dicVendorData.AsEnumerable().ToList()[0];
                if (m_kvpVendorVM.Key < 1 || (m_kvpVendorVM.Key > 1 && Exact))
                    return this.Direct(false);
                else if (m_kvpVendorVM.Key > 1 && !Exact)
                    return Browse(ControlVendorID, ControlVendorDesc, FilterVendorID, FilterVendorDesc);

                m_dicVendorData = GetVendorData(false, FilterVendorID, FilterVendorDesc);
                VendorVM m_objVendorVM = m_dicVendorData[0][0];
                this.GetCmp<TextField>(ControlVendorID).Value = m_objVendorVM.VendorID;
                this.GetCmp<TextField>(ControlVendorDesc).Value = m_objVendorVM.VendorDesc;
                return this.Direct(true);
            }
            catch (Exception ex)
            {
                return this.Direct(false, ex.Message);
            }
        }

        #endregion

        #region Private Method

        private List<string> IsSaveValid(string Action, string VendorID, string VendorSubcategoryID, string FirstName,
            string LastName, string City, string Street, string Postal, string Phone, string Email, string IDNo,
            string NPWP)
        {
            List<string> m_lstReturn = new List<string>();

            if (VendorID == string.Empty)
                m_lstReturn.Add(VendorVM.Prop.VendorID.Desc + " " + General.EnumDesc(MessageLib.mustFill));
            if (FirstName == string.Empty)
                m_lstReturn.Add(VendorVM.Prop.FirstName.Desc + " " + General.EnumDesc(MessageLib.mustFill));
            if (LastName == string.Empty)
                m_lstReturn.Add(VendorVM.Prop.LastName.Desc + " " + General.EnumDesc(MessageLib.mustFill));
            if (VendorSubcategoryID == string.Empty)
                m_lstReturn.Add(VendorVM.Prop.VendorSubcategoryDesc.Desc + " " + General.EnumDesc(MessageLib.mustFill));
            if (City == string.Empty)
                m_lstReturn.Add(VendorVM.Prop.City.Desc + " " + General.EnumDesc(MessageLib.mustFill));
            if (Street == string.Empty)
                m_lstReturn.Add(VendorVM.Prop.Street.Desc + " " + General.EnumDesc(MessageLib.mustFill));
            if (Postal == string.Empty)
                m_lstReturn.Add(VendorVM.Prop.Postal.Desc + " " + General.EnumDesc(MessageLib.mustFill));
            if (Phone == string.Empty)
                m_lstReturn.Add(VendorVM.Prop.Phone.Desc + " " + General.EnumDesc(MessageLib.mustFill));
            if (Email == string.Empty)
                m_lstReturn.Add(VendorVM.Prop.Email.Desc + " " + General.EnumDesc(MessageLib.mustFill));
            else if (!General.IsEmailValid(Email))
                m_lstReturn.Add(VendorVM.Prop.Email.Desc + " " + General.EnumDesc(MessageLib.invalid));
            if (IDNo == string.Empty)
                m_lstReturn.Add(VendorVM.Prop.IDNo.Desc + " " + General.EnumDesc(MessageLib.mustFill));
            if (NPWP == string.Empty)
                m_lstReturn.Add(VendorVM.Prop.NPWP.Desc + " " + General.EnumDesc(MessageLib.mustFill));

            return m_lstReturn;
        }

        private Dictionary<string, object> GetFormData(NameValueCollection parameters)
        {
            Dictionary<string, object> m_dicReturn = new Dictionary<string, object>();

            m_dicReturn.Add(VendorVM.Prop.VendorID.Name, parameters[VendorVM.Prop.VendorID.Name]);
            m_dicReturn.Add(VendorVM.Prop.VendorDesc.Name, parameters[VendorVM.Prop.VendorDesc.Name]);
            m_dicReturn.Add(VendorVM.Prop.VendorSubcategoryID.Name, parameters[VendorVM.Prop.VendorSubcategoryID.Name]);
            m_dicReturn.Add(VendorVM.Prop.VendorSubcategoryDesc.Name, parameters[VendorVM.Prop.VendorSubcategoryDesc.Name]);

            return m_dicReturn;
        }

        private VendorVM GetSelectedData(Dictionary<string, object> selected, ref string message)
        {
            VendorVM m_objVendorVM = new VendorVM();
            MVendorDA m_objMVendorDA = new MVendorDA();
            m_objMVendorDA.ConnectionStringName = Global.ConnStrConfigName;

            List<string> m_lstSelect = new List<string>();
            m_lstSelect.Add(VendorVM.Prop.VendorID.MapAlias);
            m_lstSelect.Add(VendorVM.Prop.LastName.MapAlias);
            m_lstSelect.Add(VendorVM.Prop.FirstName.MapAlias);
            m_lstSelect.Add(VendorVM.Prop.VendorCategoryDesc.MapAlias);
            m_lstSelect.Add(VendorVM.Prop.VendorSubcategoryID.MapAlias);
            m_lstSelect.Add(VendorVM.Prop.VendorSubcategoryDesc.MapAlias);
            m_lstSelect.Add(VendorVM.Prop.City.MapAlias);
            m_lstSelect.Add(VendorVM.Prop.Street.MapAlias);
            m_lstSelect.Add(VendorVM.Prop.Postal.MapAlias);
            m_lstSelect.Add(VendorVM.Prop.Phone.MapAlias);
            m_lstSelect.Add(VendorVM.Prop.Email.MapAlias);
            m_lstSelect.Add(VendorVM.Prop.IDNo.MapAlias);
            m_lstSelect.Add(VendorVM.Prop.NPWP.MapAlias);

            List<string> m_lstKey = new List<string>();
            Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();
            foreach (KeyValuePair<string, object> m_kvpSelectedRow in selected)
            {
                if (m_objVendorVM.IsKey(m_kvpSelectedRow.Key))
                {
                    m_lstKey.Add(m_kvpSelectedRow.Value.ToString());
                    List<object> m_lstFilter = new List<object>();
                    m_lstFilter.Add(Operator.Equals);
                    m_lstFilter.Add(m_kvpSelectedRow.Value);
                    m_objFilter.Add(VendorVM.Prop.Map(m_kvpSelectedRow.Key, false), m_lstFilter);
                }
            }

            Dictionary<int, DataSet> m_dicMVendorDA = m_objMVendorDA.SelectBC(0, 1, false, m_lstSelect, m_objFilter, null, null, null);
            if (m_objMVendorDA.Message == string.Empty)
            {
                DataRow m_drMVendorDA = m_dicMVendorDA[0].Tables[0].Rows[0];
                m_objVendorVM.VendorID = m_drMVendorDA[VendorVM.Prop.VendorID.Name].ToString();
                m_objVendorVM.LastName = m_drMVendorDA[VendorVM.Prop.LastName.Name].ToString();
                m_objVendorVM.FirstName = m_drMVendorDA[VendorVM.Prop.FirstName.Name].ToString();
                m_objVendorVM.VendorCategoryDesc = m_drMVendorDA[VendorVM.Prop.VendorCategoryDesc.Name].ToString();
                m_objVendorVM.VendorSubcategoryID = m_drMVendorDA[VendorSubcategoryVM.Prop.VendorSubcategoryID.Name].ToString();
                m_objVendorVM.VendorSubcategoryDesc = m_drMVendorDA[VendorSubcategoryVM.Prop.VendorSubcategoryDesc.Name].ToString();
                m_objVendorVM.City = m_drMVendorDA[VendorVM.Prop.City.Name].ToString();
                m_objVendorVM.Street = m_drMVendorDA[VendorVM.Prop.Street.Name].ToString();
                m_objVendorVM.Postal = m_drMVendorDA[VendorVM.Prop.Postal.Name].ToString();
                m_objVendorVM.Phone = m_drMVendorDA[VendorVM.Prop.Phone.Name].ToString();
                m_objVendorVM.Email = m_drMVendorDA[VendorVM.Prop.Email.Name].ToString();
                m_objVendorVM.IDNo = m_drMVendorDA[VendorVM.Prop.IDNo.Name].ToString();
                m_objVendorVM.NPWP = m_drMVendorDA[VendorVM.Prop.NPWP.Name].ToString();
            }
            else
                message = "[" + String.Join(Global.OneLineSeparated, m_lstKey) + "] " + m_objMVendorDA.Message;

            return m_objVendorVM;
        }

        #endregion

        #region Public Method

        public Dictionary<int, List<VendorVM>> GetVendorData(bool isCount, string VendorID, string VendorDesc)
        {
            int m_intCount = 0;
            List<VendorVM> m_lstVendorVM = new List<ViewModels.VendorVM>();
            Dictionary<int, List<VendorVM>> m_dicReturn = new Dictionary<int, List<VendorVM>>();
            MVendorDA m_objMVendorDA = new MVendorDA();
            m_objMVendorDA.ConnectionStringName = Global.ConnStrConfigName;

            List<string> m_lstSelect = new List<string>();
            m_lstSelect.Add(VendorVM.Prop.VendorID.MapAlias);
            m_lstSelect.Add(VendorVM.Prop.VendorDesc.MapAlias);

            Dictionary<string, List<object>> m_objFilter = new Dictionary<string, List<object>>();
            List<object> m_lstFilter = new List<object>();
            m_lstFilter.Add(Operator.Contains);
            m_lstFilter.Add(VendorID);
            m_objFilter.Add(VendorVM.Prop.VendorID.Map, m_lstFilter);

            m_lstFilter = new List<object>();
            m_lstFilter.Add(Operator.Contains);
            m_lstFilter.Add(VendorDesc);
            m_objFilter.Add(VendorVM.Prop.VendorDesc.Map, m_lstFilter);

            Dictionary<int, DataSet> m_dicMVendorDA = m_objMVendorDA.SelectBC(0, null, isCount, m_lstSelect, m_objFilter, null, null, null);
            if (m_objMVendorDA.Message == string.Empty)
            {
                if (isCount)
                    foreach (KeyValuePair<int, DataSet> m_kvpVendorBL in m_dicMVendorDA)
                    {
                        m_intCount = m_kvpVendorBL.Key;
                        break;
                    }
                else
                {
                    m_lstVendorVM = (
                        from DataRow m_drMVendorDA in m_dicMVendorDA[0].Tables[0].Rows
                        select new VendorVM()
                        {
                            VendorID = m_drMVendorDA[VendorVM.Prop.VendorID.Name].ToString(),
                            VendorDesc = m_drMVendorDA[VendorVM.Prop.VendorDesc.Name].ToString()
                        }
                    ).ToList();
                }
            }
            m_dicReturn.Add(m_intCount, m_lstVendorVM);
            return m_dicReturn;
        }

        #endregion
    }
}