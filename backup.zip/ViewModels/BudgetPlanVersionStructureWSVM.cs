﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace com.SML.BIGTRONS.ViewModels
{
    public class BudgetPlanVersionStructureWSVM
    {
        public string WorkItem { get; set; }
        public decimal Amount { get; set; }
    }
}